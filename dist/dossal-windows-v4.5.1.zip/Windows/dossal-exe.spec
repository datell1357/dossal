# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['dossal_gui.py'],
    pathex=[],
    binaries=[],
    datas=[('dossal.py', '.'), ('README.md', '.')],
    hiddenimports=['h2', 'psutil'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='dossal-exe',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
app = BUNDLE(
    exe,
    name='dossal-exe.app',
    icon=None,
    bundle_identifier=None,
)
